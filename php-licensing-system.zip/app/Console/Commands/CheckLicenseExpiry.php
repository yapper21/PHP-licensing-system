<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\License;
use App\Models\AuditLog;
use Illuminate\Support\Facades\Mail;

class CheckLicenseExpiry extends Command
{
    protected $signature = 'app:check-license-expiry';
    protected $description = 'Scan active licenses and handle expiration and reminders';

    public function handle()
    {
        $this->info('Starting license expiry checks...');

        $now = now();
        $activeLicenses = License::where('status', 'active')
            ->whereNotNull('expiry_date')
            ->get();

        $expiredCount = 0;
        $reminderCount = 0;

        foreach ($activeLicenses as $license) {
            $expiryWithGrace = $license->expiry_date->copy()->addDays($license->grace_period_days);

            if ($expiryWithGrace->isPast()) {
                $license->update(['status' => 'expired']);
                
                AuditLog::create([
                    'event' => 'license_expired',
                    'description' => "License {$license->license_key} has expired (expired on {$license->expiry_date->toDateString()})",
                    'ip_address' => '127.0.0.1',
                ]);

                $this->warn("License {$license->license_key} has been marked as expired.");
                $expiredCount++;
                continue;
            }

            // Handle grace period reminders
            if ($license->expiry_date->isPast() && $expiryWithGrace->isFuture()) {
                $daysLeft = (int) ceil($now->diffInMinutes($expiryWithGrace) / (24 * 60));
                $this->info("License {$license->license_key} is in grace period. {$daysLeft} days remaining.");
                
                AuditLog::create([
                    'event' => 'license_grace_period_warning',
                    'description' => "License {$license->license_key} is in its grace period. Expires completely in {$daysLeft} days.",
                    'ip_address' => '127.0.0.1',
                ]);
                
                Mail::raw("Your license {$license->license_key} has expired but is in a grace period. Please renew to avoid service disruption.", function ($message) use ($license) {
                    $message->to($license->customer->email)
                        ->subject("License Expiration Grace Period Warning - {$license->license_key}");
                });
                
                $reminderCount++;
            } elseif ($license->expiry_date->isFuture() && $now->diffInDays($license->expiry_date) <= 7) {
                // Expiring soon reminder (within 7 days)
                $daysLeft = $now->diffInDays($license->expiry_date);
                
                Mail::raw("Your license {$license->license_key} will expire in {$daysLeft} days. Please renew to ensure continuous service.", function ($message) use ($license) {
                    $message->to($license->customer->email)
                        ->subject("Your license will expire soon - {$license->license_key}");
                });
                
                $this->info("License {$license->license_key} will expire soon. Reminder sent.");
                $reminderCount++;
            }
        }

        $this->info("Finished license expiry checks. Expired: {$expiredCount}, Reminders sent: {$reminderCount}");
        return 0;
    }
}
