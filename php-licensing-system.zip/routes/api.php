<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\LicenseController;

Route::post('/auth/login', [AuthController::class, 'login']);

// Public endpoints for client application license management
Route::post('/licenses/activate', [LicenseController::class, 'activate']);
Route::post('/licenses/validate', [LicenseController::class, 'validateLicense']);
Route::post('/licenses/deactivate', [LicenseController::class, 'deactivate']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/licenses/{license_key}', [LicenseController::class, 'show']);
});