<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'version', 'description', 'license_type', 'status'
    ];

    public function licenses()
    {
        return $this->hasMany(License::class);
    }
}