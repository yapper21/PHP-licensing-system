<?php

namespace App\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use App\Models\Customer;
use App\Models\License;

class StatsOverview extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $totalCustomers = Customer::count();
        $activeLicenses = License::where('status', 'active')->count();
        $expiredLicenses = License::where('status', 'expired')->count();
        
        $monthlyCount = License::where('type', 'monthly')->where('status', 'active')->count();
        $annualCount = License::where('type', 'annual')->where('status', 'active')->count();
        $lifetimeCount = License::where('type', 'lifetime')->where('status', 'active')->count();
        
        $estimatedMRR = ($monthlyCount * 10) + (($annualCount * 100) / 12);

        return [
            Stat::make('Total Customers', $totalCustomers)
                ->description('Registered accounts')
                ->descriptionIcon('heroicon-m-users')
                ->color('success'),
            Stat::make('Active Licenses', $activeLicenses)
                ->description('Currently active keys')
                ->descriptionIcon('heroicon-m-key')
                ->color('primary'),
            Stat::make('Expired Licenses', $expiredLicenses)
                ->description('Awaiting renewal')
                ->descriptionIcon('heroicon-m-exclamation-triangle')
                ->color('danger'),
            Stat::make('Est. Monthly Revenue (MRR)', '$' . number_format($estimatedMRR, 2))
                ->description('Based on active subscriptions')
                ->descriptionIcon('heroicon-m-currency-dollar')
                ->color('success'),
        ];
    }
}
