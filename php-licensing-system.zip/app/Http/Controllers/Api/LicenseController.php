<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\License;
use App\Models\Installation;
use App\Models\AuditLog;

class LicenseController extends Controller
{
    public function activate(Request $request)
    {
        $request->validate([
            'license_key' => 'required|string',
            'installation_id' => 'required|string',
            'domain' => 'required|string',
            'software_version' => 'nullable|string',
        ]);

        $license = License::where('license_key', $request->license_key)->first();

        if (!$license || !$license->isValid()) {
            return response()->json([
                'status' => 'invalid',
                'message' => 'License is invalid, expired, suspended, or revoked'
            ], 403);
        }

        // Check if this installation is already registered
        $existingInstallation = Installation::where('license_id', $license->id)
            ->where('installation_id', $request->installation_id)
            ->first();

        if (!$existingInstallation) {
            // Check activation limit
            if ($license->installations()->count() >= $license->activation_limit) {
                return response()->json([
                    'status' => 'limit_exceeded',
                    'message' => 'Activation limit reached'
                ], 403);
            }
        }

        $installation = Installation::updateOrCreate(
            [
                'license_id' => $license->id,
                'installation_id' => $request->installation_id
            ],
            [
                'domain' => $request->domain,
                'ip_address' => $request->ip(),
                'activation_date' => now(),
                'last_validation_date' => now(),
                'software_version' => $request->software_version ?? '1.0.0',
            ]
        );

        // Log the action
        AuditLog::create([
            'event' => 'license_activated',
            'description' => "License {$license->license_key} activated on {$request->domain} (ID: {$request->installation_id})",
            'ip_address' => $request->ip(),
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'License activated successfully',
            'expiry_date' => $license->expiry_date ? $license->expiry_date->toDateString() : null,
            'activation_token' => $installation->id . '-' . now()->timestamp
        ]);
    }

    public function validateLicense(Request $request)
    {
        $request->validate([
            'license_key' => 'required|string',
            'installation_id' => 'required|string',
        ]);

        $license = License::where('license_key', $request->license_key)->first();

        if (!$license || !$license->isValid()) {
            return response()->json([
                'status' => 'invalid',
                'message' => 'License is invalid, expired, suspended, or revoked'
            ], 403);
        }

        // Check if installation is registered
        $installation = Installation::where('license_id', $license->id)
            ->where('installation_id', $request->installation_id)
            ->first();

        if (!$installation) {
            return response()->json([
                'status' => 'invalid',
                'message' => 'Installation not registered for this license'
            ], 403);
        }

        // Update validation details
        $installation->update([
            'last_validation_date' => now(),
            'ip_address' => $request->ip(),
        ]);

        // Log validation
        AuditLog::create([
            'event' => 'license_validated',
            'description' => "License {$license->license_key} validated for installation {$request->installation_id}",
            'ip_address' => $request->ip(),
        ]);

        // Map plan to allowed features
        $allowedFeatures = match ($license->plan) {
            'enterprise' => ['core', 'reporting', 'api_access', 'priority_support', 'multi_user'],
            'professional' => ['core', 'reporting', 'api_access'],
            default => ['core'],
        };

        return response()->json([
            'status' => 'valid',
            'expiry_date' => $license->expiry_date ? $license->expiry_date->toDateString() : null,
            'subscription_status' => $license->status,
            'allowed_features' => $allowedFeatures,
            'message' => 'License is valid'
        ]);
    }

    public function deactivate(Request $request)
    {
        $request->validate([
            'license_key' => 'required|string',
            'installation_id' => 'required|string',
        ]);

        $license = License::where('license_key', $request->license_key)->first();

        if (!$license) {
            return response()->json([
                'status' => 'error',
                'message' => 'License not found'
            ], 404);
        }

        $installation = Installation::where('license_id', $license->id)
            ->where('installation_id', $request->installation_id)
            ->first();

        if (!$installation) {
            return response()->json([
                'status' => 'error',
                'message' => 'Installation not found'
            ], 404);
        }

        $installation->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Installation deactivated successfully'
        ]);
    }

    public function show($license_key)
    {
        $license = License::with(['product', 'customer'])->where('license_key', $license_key)->first();

        if (!$license) {
            return response()->json(['message' => 'License not found'], 404);
        }

        return response()->json($license);
    }
}