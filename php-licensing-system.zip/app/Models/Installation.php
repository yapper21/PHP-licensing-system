<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Installation extends Model
{
    use HasFactory;

    protected $fillable = [
        'license_id', 'installation_id', 'domain', 
        'ip_address', 'software_version', 'activation_date', 'last_validation_date'
    ];

    protected $casts = [
        'activation_date' => 'datetime',
        'last_validation_date' => 'datetime',
    ];

    public function license()
    {
        return $this->belongsTo(License::class);
    }

    protected static function booted()
    {
        static::deleted(function ($installation) {
            $licenseKey = $installation->license->license_key ?? 'Unknown';
            \App\Models\AuditLog::create([
                'event' => 'license_deactivated',
                'description' => "Installation {$installation->installation_id} for license key {$licenseKey} was deactivated/deleted.",
                'ip_address' => request()->ip(),
            ]);
        });
    }
}