<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('licenses', function (Blueprint $table) {
            $table->id();
            $table->string('license_key')->unique();
            $table->foreignId('product_id')->constrained()->onDelete('cascade');
            $table->foreignId('customer_id')->constrained()->onDelete('cascade');
            $table->string('type')->default('lifetime'); // lifetime, annual, monthly, trial
            $table->string('plan')->default('basic'); // basic, professional, enterprise
            $table->integer('activation_limit')->default(1);
            $table->timestamp('expiry_date')->nullable();
            $table->integer('grace_period_days')->default(0);
            $table->enum('status', ['active', 'expired', 'suspended', 'revoked'])->default('active');
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('licenses');
    }
};