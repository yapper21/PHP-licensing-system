<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Customer;
use App\Models\Product;
use App\Models\License;
use App\Models\Installation;

class LicensingApiTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private License $license;
    private Product $product;
    private Customer $customer;

    protected function setUp(): void
    {
        parent::setUp();

        // Create admin user
        $this->admin = User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'password' => bcrypt('password'),
        ]);

        // Create product
        $this->product = Product::create([
            'name' => 'Test Software',
            'version' => '1.0.0',
            'description' => 'Test Desc',
            'license_type' => 'annual',
            'status' => 'active',
        ]);

        // Create customer
        $this->customer = Customer::create([
            'name' => 'Test Client',
            'email' => 'client@example.com',
            'company_name' => 'Client Inc.',
        ]);

        // Create active license with limit = 2
        $this->license = License::create([
            'license_key' => 'LIC-TESTKEY123',
            'product_id' => $this->product->id,
            'customer_id' => $this->customer->id,
            'type' => 'annual',
            'plan' => 'professional',
            'activation_limit' => 2,
            'expiry_date' => now()->addYear(),
            'grace_period_days' => 7,
            'status' => 'active',
        ]);
    }

    /** @test */
    public function it_authenticates_admin_users()
    {
        // Invalid login
        $response = $this->postJson('/api/auth/login', [
            'email' => 'admin@example.com',
            'password' => 'wrongpassword',
        ]);

        $response->assertStatus(401)
            ->assertJsonStructure(['message']);

        // Valid login
        $response = $this->postJson('/api/auth/login', [
            'email' => 'admin@example.com',
            'password' => 'password',
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure(['message', 'user', 'token']);
    }

    /** @test */
    public function it_activates_a_valid_license()
    {
        $response = $this->postJson('/api/licenses/activate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site.com',
            'software_version' => '1.0.5',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'status' => 'success',
                'message' => 'License activated successfully',
            ])
            ->assertJsonStructure(['expiry_date', 'activation_token']);

        $this->assertDatabaseHas('installations', [
            'license_id' => $this->license->id,
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site.com',
        ]);

        $this->assertDatabaseHas('audit_logs', [
            'event' => 'license_activated',
        ]);
    }

    /** @test */
    public function license_activation_is_idempotent()
    {
        // First activation
        $this->postJson('/api/licenses/activate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site.com',
        ])->assertStatus(200);

        // Second activation with same details should succeed and return success (idempotent)
        $response = $this->postJson('/api/licenses/activate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site.com',
        ]);

        $response->assertStatus(200)
            ->assertJson(['status' => 'success']);

        $this->assertEquals(1, $this->license->installations()->count());
    }

    /** @test */
    public function it_enforces_activation_limits()
    {
        // Active 1
        $this->postJson('/api/licenses/activate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site1.com',
        ])->assertStatus(200);

        // Active 2
        $this->postJson('/api/licenses/activate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-2',
            'domain' => 'client-site2.com',
        ])->assertStatus(200);

        // Active 3 (Should fail because limit is 2)
        $response = $this->postJson('/api/licenses/activate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-3',
            'domain' => 'client-site3.com',
        ]);

        $response->assertStatus(403)
            ->assertJson([
                'status' => 'limit_exceeded',
                'message' => 'Activation limit reached',
            ]);
    }

    /** @test */
    public function it_validates_active_license_installations()
    {
        // Setup installation
        $installation = Installation::create([
            'license_id' => $this->license->id,
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site.com',
            'ip_address' => '127.0.0.1',
            'activation_date' => now(),
            'last_validation_date' => now(),
        ]);

        $response = $this->postJson('/api/licenses/validate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'status' => 'valid',
                'subscription_status' => 'active',
                'allowed_features' => ['core', 'reporting', 'api_access'], // professional plan
            ]);

        $this->assertDatabaseHas('audit_logs', [
            'event' => 'license_validated',
        ]);
    }

    /** @test */
    public function it_fails_validation_for_unregistered_installations()
    {
        $response = $this->postJson('/api/licenses/validate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'unregistered-device',
        ]);

        $response->assertStatus(403)
            ->assertJson([
                'status' => 'invalid',
            ]);
    }

    /** @test */
    public function it_deactivates_installations()
    {
        // Setup installation
        $installation = Installation::create([
            'license_id' => $this->license->id,
            'installation_id' => 'inst-device-1',
            'domain' => 'client-site.com',
            'ip_address' => '127.0.0.1',
            'activation_date' => now(),
            'last_validation_date' => now(),
        ]);

        $response = $this->postJson('/api/licenses/deactivate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'status' => 'success',
                'message' => 'Installation deactivated successfully',
            ]);

        $this->assertDatabaseMissing('installations', [
            'id' => $installation->id,
        ]);

        // Further validation of this installation must now fail
        $this->postJson('/api/licenses/validate', [
            'license_key' => 'LIC-TESTKEY123',
            'installation_id' => 'inst-device-1',
        ])->assertStatus(403);
    }

    /** @test */
    public function it_allows_authorized_admin_to_fetch_license_info()
    {
        // Unauthenticated call
        $this->getJson("/api/licenses/{$this->license->license_key}")
            ->assertStatus(401);

        // Authenticated call
        $token = $this->admin->createToken('test-token')->plainTextToken;

        $response = $this->withHeader('Authorization', "Bearer {$token}")
            ->getJson("/api/licenses/{$this->license->license_key}");

        $response->assertStatus(200)
            ->assertJsonFragment([
                'license_key' => 'LIC-TESTKEY123',
                'plan' => 'professional',
            ]);
    }
}
