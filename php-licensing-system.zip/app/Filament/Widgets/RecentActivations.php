<?php

namespace App\Filament\Widgets;

use Filament\Widgets\TableWidget as BaseWidget;
use Filament\Tables;
use Filament\Tables\Table;
use App\Models\Installation;

class RecentActivations extends BaseWidget
{
    protected static ?int $sort = 2;
    
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Installation::query()->latest()->limit(5)
            )
            ->columns([
                Tables\Columns\TextColumn::make('installation_id')
                    ->label('Installation ID')
                    ->searchable(),
                Tables\Columns\TextColumn::make('license.license_key')
                    ->label('License Key')
                    ->searchable(),
                Tables\Columns\TextColumn::make('domain')
                    ->label('Domain')
                    ->searchable(),
                Tables\Columns\TextColumn::make('ip_address')
                    ->label('IP Address'),
                Tables\Columns\TextColumn::make('activation_date')
                    ->label('Activated At')
                    ->dateTime(),
            ])
            ->paginated(false);
    }
}
