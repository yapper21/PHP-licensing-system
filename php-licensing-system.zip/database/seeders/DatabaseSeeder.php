<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Customer;
use App\Models\Product;
use App\Models\License;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Seed admin user for Filament panel
        \App\Models\User::firstOrCreate(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Admin User',
                'password' => bcrypt('password'),
            ]
        );

        $customer = Customer::create([
            'name' => 'John Doe',
            'company_name' => 'Acme Corp',
            'email' => 'john@example.com',
        ]);

        $product = Product::create([
            'name' => 'My Awesome Software',
            'version' => '1.0',
            'description' => 'Premium PHP Application',
            'license_type' => 'annual',
            'status' => 'active',
        ]);

        License::create([
            'license_key' => 'LIC-TESTKEY123',
            'product_id' => $product->id,
            'customer_id' => $customer->id,
            'type' => 'annual',
            'plan' => 'professional',
            'activation_limit' => 3,
            'expiry_date' => now()->addYear(),
            'grace_period_days' => 7,
            'status' => 'active',
        ]);
    }
}