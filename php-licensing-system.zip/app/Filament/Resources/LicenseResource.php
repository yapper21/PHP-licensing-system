<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LicenseResource\Pages;
use App\Models\License;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;

class LicenseResource extends Resource
{
    protected static ?string $model = License::class;

    protected static ?string $navigationIcon = 'heroicon-o-key';

    protected static ?string $navigationGroup = 'Licensing';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('customer_id')
                    ->relationship('customer', 'name')
                    ->required()
                    ->searchable()
                    ->preload(),

                Select::make('product_id')
                    ->relationship('product', 'name')
                    ->required()
                    ->searchable()
                    ->preload(),

                TextInput::make('license_key')
                    ->label('License Key')
                    ->unique(ignoreRecord: true)
                    ->required()
                    ->readOnly()
                    ->default(fn () => 'LIC-' . strtoupper(bin2hex(random_bytes(6)))),

                Select::make('type')
                    ->options([
                        'lifetime' => 'Lifetime License',
                        'annual' => 'Annual Subscription',
                        'monthly' => 'Monthly Subscription',
                        'trial' => 'Trial License',
                    ])
                    ->default('lifetime')
                    ->required(),

                Select::make('plan')
                    ->options([
                        'basic' => 'Basic Plan',
                        'professional' => 'Professional Plan',
                        'enterprise' => 'Enterprise Plan',
                    ])
                    ->default('basic')
                    ->required(),

                TextInput::make('activation_limit')
                    ->numeric()
                    ->default(1)
                    ->required()
                    ->minValue(1),

                DatePicker::make('expiry_date')
                    ->nullable()
                    ->label('Expiry Date'),

                TextInput::make('grace_period_days')
                    ->numeric()
                    ->default(0)
                    ->required()
                    ->label('Grace Period (Days)'),

                Select::make('status')
                    ->options([
                        'active'    => 'Active',
                        'suspended' => 'Suspended',
                        'expired'   => 'Expired',
                        'revoked'   => 'Revoked',
                    ])
                    ->default('active')
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('license_key')
                    ->searchable()
                    ->copyable()
                    ->sortable(),

                TextColumn::make('customer.name')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('product.name')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('type')
                    ->badge()
                    ->color('gray')
                    ->sortable(),

                TextColumn::make('plan')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'enterprise' => 'danger',
                        'professional' => 'info',
                        default => 'success',
                    })
                    ->sortable(),

                TextColumn::make('status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'active' => 'success',
                        'revoked' => 'danger',
                        'suspended' => 'warning',
                        'expired' => 'gray',
                    })
                    ->sortable(),

                TextColumn::make('activation_limit')
                    ->sortable(),

                TextColumn::make('expiry_date')
                    ->date()
                    ->sortable(),

                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'active' => 'Active',
                        'suspended' => 'Suspended',
                        'expired' => 'Expired',
                        'revoked' => 'Revoked',
                    ]),
                Tables\Filters\SelectFilter::make('plan')
                    ->options([
                        'basic' => 'Basic Plan',
                        'professional' => 'Professional Plan',
                        'enterprise' => 'Enterprise Plan',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\Action::make('renew')
                        ->label('Renew License')
                        ->icon('heroicon-o-arrow-path')
                        ->color('success')
                        ->form([
                            DatePicker::make('expiry_date')
                                ->label('New Expiry Date')
                                ->required()
                                ->default(now()->addYear()),
                        ])
                        ->action(function (License $record, array $data) {
                            $record->update([
                                'expiry_date' => $data['expiry_date'],
                                'status' => 'active',
                            ]);
                            \App\Models\AuditLog::create([
                                'event' => 'license_renewed',
                                'description' => "License {$record->license_key} renewed until {$data['expiry_date']}",
                                'ip_address' => request()->ip(),
                            ]);
                        }),
                    Tables\Actions\Action::make('suspend')
                        ->label('Suspend License')
                        ->icon('heroicon-o-pause')
                        ->color('warning')
                        ->requiresConfirmation()
                        ->visible(fn (License $record) => $record->status === 'active')
                        ->action(function (License $record) {
                            $record->update(['status' => 'suspended']);
                            \App\Models\AuditLog::create([
                                'event' => 'license_suspended',
                                'description' => "License {$record->license_key} suspended",
                                'ip_address' => request()->ip(),
                            ]);
                        }),
                    Tables\Actions\Action::make('unsuspend')
                        ->label('Activate / Unsuspend')
                        ->icon('heroicon-o-play')
                        ->color('success')
                        ->requiresConfirmation()
                        ->visible(fn (License $record) => $record->status !== 'active')
                        ->action(function (License $record) {
                            $record->update(['status' => 'active']);
                            \App\Models\AuditLog::create([
                                'event' => 'license_activated',
                                'description' => "License {$record->license_key} status activated manually",
                                'ip_address' => request()->ip(),
                            ]);
                        }),
                    Tables\Actions\Action::make('revoke')
                        ->label('Revoke License')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->requiresConfirmation()
                        ->action(function (License $record) {
                            $record->update(['status' => 'revoked']);
                            \App\Models\AuditLog::create([
                                'event' => 'license_revoked',
                                'description' => "License {$record->license_key} revoked",
                                'ip_address' => request()->ip(),
                            ]);
                        }),
                    Tables\Actions\Action::make('upgrade')
                        ->label('Upgrade Plan')
                        ->icon('heroicon-o-arrow-up-circle')
                        ->color('info')
                        ->form([
                            Select::make('plan')
                                ->options([
                                    'basic' => 'Basic Plan',
                                    'professional' => 'Professional Plan',
                                    'enterprise' => 'Enterprise Plan',
                                ])
                                ->required(),
                            TextInput::make('activation_limit')
                                ->numeric()
                                ->required()
                                ->minValue(1),
                        ])
                        ->action(function (License $record, array $data) {
                            $record->update([
                                'plan' => $data['plan'],
                                'activation_limit' => $data['activation_limit'],
                            ]);
                            \App\Models\AuditLog::create([
                                'event' => 'license_upgraded',
                                'description' => "License {$record->license_key} upgraded to {$data['plan']} with limit {$data['activation_limit']}",
                                'ip_address' => request()->ip(),
                            ]);
                        }),
                ]),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListLicenses::route('/'),
            'create' => Pages\CreateLicense::route('/create'),
            'edit'   => Pages\EditLicense::route('/{record}/edit'),
        ];
    }
}