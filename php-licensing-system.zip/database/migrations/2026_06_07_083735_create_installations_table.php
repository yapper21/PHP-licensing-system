<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('installations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('license_id')->constrained()->onDelete('cascade');
            $table->string('installation_id')->unique();
            $table->string('domain')->nullable();
            $table->string('ip_address')->nullable();
            $table->timestamp('activation_date')->useCurrent();
            $table->timestamp('last_validation_date')->nullable();
            $table->string('software_version')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('installations');
    }
};