<?php

namespace App\Filament\Resources;

use App\Filament\Resources\InstallationResource\Pages;
use App\Models\Installation;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DateTimePicker;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;

class InstallationResource extends Resource
{
    protected static ?string $model = Installation::class;

    protected static ?string $navigationIcon = 'heroicon-o-computer-desktop';

    protected static ?string $navigationGroup = 'Licensing';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('license_id')
                    ->relationship('license', 'license_key')
                    ->required()
                    ->disabled()
                    ->dehydrated(true),
                TextInput::make('installation_id')
                    ->required()
                    ->disabled()
                    ->dehydrated(true)
                    ->maxLength(255),
                TextInput::make('domain')
                    ->disabled()
                    ->dehydrated(true)
                    ->maxLength(255),
                TextInput::make('ip_address')
                    ->disabled()
                    ->dehydrated(true)
                    ->maxLength(255),
                DateTimePicker::make('activation_date')
                    ->disabled()
                    ->dehydrated(true),
                DateTimePicker::make('last_validation_date')
                    ->disabled()
                    ->dehydrated(true),
                TextInput::make('software_version')
                    ->disabled()
                    ->dehydrated(true)
                    ->maxLength(255),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('installation_id')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('license.license_key')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('domain')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('ip_address')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('software_version')
                    ->sortable(),
                TextColumn::make('last_validation_date')
                    ->dateTime()
                    ->sortable(),
                TextColumn::make('activation_date')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\Action::make('force_reactivate')
                    ->label('Force Reactivate')
                    ->icon('heroicon-o-arrow-path')
                    ->color('warning')
                    ->requiresConfirmation()
                    ->modalHeading('Force Installation Reactivation')
                    ->modalDescription('This will deactivate the current installation and force the client application to reactivate. Proceed?')
                    ->action(function (Installation $record) {
                        $licenseKey = $record->license->license_key ?? 'Unknown';
                        \App\Models\AuditLog::create([
                            'event' => 'license_force_reactivation',
                            'description' => "Force reactivation triggered for installation {$record->installation_id} of license key {$licenseKey}.",
                            'ip_address' => request()->ip(),
                        ]);
                        $record->delete();
                    }),
                Tables\Actions\DeleteAction::make()
                    ->label('Deactivate'),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListInstallations::route('/'),
            'create' => Pages\CreateInstallation::route('/create'),
            'edit' => Pages\EditInstallation::route('/{record}/edit'),
        ];
    }
}
