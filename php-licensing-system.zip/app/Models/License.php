<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class License extends Model
{
    use HasFactory;

    protected $fillable = [
        'license_key', 'product_id', 'customer_id', 'type', 'plan',
        'activation_limit', 'expiry_date', 'grace_period_days', 'status'
    ];

    protected $casts = [
        'expiry_date' => 'datetime',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function installations()
    {
        return $this->hasMany(Installation::class);
    }

    public function isValid(): bool
    {
        if ($this->status !== 'active') {
            return false;
        }

        if ($this->expiry_date === null) {
            return true;
        }

        // Account for grace period
        $expiryWithGrace = $this->expiry_date->copy()->addDays($this->grace_period_days ?? 0);
        return $expiryWithGrace->isFuture() || $expiryWithGrace->isToday();
    }

    protected static function booted()
    {
        static::created(function ($license) {
            $productName = $license->product->name ?? 'Unknown';
            $customerName = $license->customer->name ?? 'Unknown';
            \App\Models\AuditLog::create([
                'event' => 'license_created',
                'description' => "License key {$license->license_key} was created for product {$productName} and customer {$customerName}.",
                'ip_address' => request()->ip(),
            ]);
        });

        static::updated(function ($license) {
            if ($license->isDirty('status')) {
                $oldStatus = $license->getOriginal('status');
                $newStatus = $license->status;
                
                $event = match ($newStatus) {
                    'suspended' => 'license_suspended',
                    'revoked' => 'license_revoked',
                    'active' => 'license_activated',
                    default => 'license_updated',
                };
                
                \App\Models\AuditLog::create([
                    'event' => $event,
                    'description' => "License key {$license->license_key} status changed from {$oldStatus} to {$newStatus}.",
                    'ip_address' => request()->ip(),
                ]);
            }
        });
    }
}